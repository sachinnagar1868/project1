({
    showOptions : function(component, event, helper) {
        event.stopPropagation();
		var cmpTarget = component.find('myPicklist');
		$A.util.toggleClass(cmpTarget, "slds-is-open"); 
	},
    selectValue : function(component, event, helper) {
        event.stopPropagation();
        helper.selectValue(component, event, helper);
    },    
    /* Method to search Accounts on keyup */
    search : function(component, event, helper) {
        helper.search(component, event, helper);
    },    
    /* Method to close dropdown */
    closeDropdown : function (component, event, helper) {
        //alert('closing..');
        event.stopPropagation();
        var cmpTarget = component.find('myPicklist');
        $A.util.removeClass(cmpTarget, 'slds-is-open');
    }
})