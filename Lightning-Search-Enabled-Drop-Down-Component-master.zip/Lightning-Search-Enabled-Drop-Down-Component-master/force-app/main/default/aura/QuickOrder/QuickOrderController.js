({
	doInit : function(component, event, helper) {
            var action = component.get("c.queryProducts");
            action.setCallback(this, function(data) {
                var result = data.getReturnValue()
				var opts = [];
                  /*
                opts.push({
                    class: "optionClass",
                    label: "",
                    value: ""
                }); */
 				for (var i in result){
                    opts.push({
                        class: "optionClass",
                        label: result[i],
                        value: i
                    });
                }
                component.set("v.products", opts);
        });
        $A.enqueueAction(action);
        
        action = component.get("c.queryAccounts");
        action.setCallback(this, function(data) {
            var result = data.getReturnValue()
            var opts = [];
            for (var i in result){
                opts.push({
                    class: "optionClass",
                    label: result[i],
                    value: i
                });
            }
            component.set("v.accounts", opts);
        });
        $A.enqueueAction(action);  
	}
})